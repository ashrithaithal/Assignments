import { connect } from 'react-redux';
import CheckOut from '../components/CheckOut';
import { getTotal, getCurrency } from '../ducks/cart';
const mapStateToProps = (state, props) => {
    return {
        amount: getTotal(state, props) + 0.1*getTotal(state, props),
        currency: getCurrency(state, props)
    }
}
export default connect(mapStateToProps)(CheckOut);