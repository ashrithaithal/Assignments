import React from 'react';
import PropTypes from 'prop-types';


const CheckOut = ({ amount, currency }) => {
return (
<div>
<h2>Amount To Be Paid:</h2>
Amount: {amount} {currency}
</div>
);
}
CheckOut.propTypes = {
    amount: PropTypes.number.isRequired,
    currency: PropTypes.string.isRequired
}

export default CheckOut;

