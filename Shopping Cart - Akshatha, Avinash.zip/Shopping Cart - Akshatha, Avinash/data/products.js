const data = [
  {
    id: 1,
    name: 'Ohrensessel Josslyn',
    price: 49999,
    currency: 'INR',
    image: 'images/01.jpg',
  },
  {
    id: 2,
    name: 'Sessel Sofie',
    price: 24999,
    currency: 'INR',
    image: 'images/02.jpg',
  },
  {
    id: 4,
    name: 'Schlafsessel Rovigo',
    price: 23999,
    currency: 'INR',
    image: 'images/04.jpg',
  },
  {
    id: 6,
    name: 'Sessel Little',
    price: 11999,
    currency: 'INR',
    image: 'images/06.jpg',
  },
  {
    id: 5,
    name: 'Sessel Peacock',
    price: 59999,
    currency: 'INR',
    image: 'images/05.jpg',
  },
  {
    id: 3,
    name: 'Sessel Anna',
    price: 14999,
    currency: 'INR',
    image: 'images/03.jpg',
  }
];

export default data;
