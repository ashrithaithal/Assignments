import React from 'react';
import Cart from './containers/Cart';
import ProductList from './containers/ProductList';
import CheckOut from './containers/CheckOut';


const App = () => {
    return (
        <div className="container">
            <div className="row">
                <div className="col-md-12">
                    <h1>Shopping Cart</h1>
                </div>
            </div>
            <div className="row">
                <div className="col-md-8">
                    <ProductList />
                </div>
                <div className="col-md-4">
                    <Cart />
                </div>
            </div>
           <h1 id="check">
             Check Out </h1>
           <div><CheckOut /></div>
           <br></br>
            <footer>
                <small>
                    made by Akshatha and Avinash, source code available on <a href="https://github.com/avinash-shenoy/Shopping-cart">github</a>
                </small>
            </footer>
        </div>
    );
}

export default App;
